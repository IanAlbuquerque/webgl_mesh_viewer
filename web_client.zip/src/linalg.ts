export { Vector3 } from "./linalg/types/vector3";
export { normalFromTriangleVertices } from "./linalg/functions";

